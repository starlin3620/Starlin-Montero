# MiDía 1.0

Panel personal de trabajo adaptable a iPhone y computadora.

## Incluye
- Tareas con estado completado y eliminación.
- Notas y descarga de texto.
- Registro manual de ingresos y gastos en RD$ y exportación CSV.
- Bloc de código y descarga de archivos.
- Enlaces rápidos a herramientas externas de IA, correo, archivos, diseño, calendario y desarrollo.
- Copia de seguridad JSON.

## Uso
Abre `index.html` en un navegador moderno. Las tareas, notas y movimientos se guardan en el almacenamiento local del navegador del dispositivo. No se sincronizan automáticamente entre dispositivos y no son un sistema de autenticación.

## Publicar desde iPhone con GitHub Pages
1. Abre tu repositorio de GitHub en Safari.
2. Entra a `Add file` > `Upload files`.
3. Sube `index.html` (puedes descargarlo desde este paquete y elegirlo en Archivos).
4. Confirma el commit.
5. En el repositorio, abre `Settings` > `Pages`.
6. En `Build and deployment`, elige `Deploy from a branch`, selecciona `main` y la carpeta `/ (root)`, y pulsa `Save`.
7. Espera a que GitHub Pages publique la web y usa el enlace que aparece en esa sección.

## Importante sobre privacidad
La página no tiene inicio de sesión. GitHub Pages publica una web accesible por enlace; por tanto, no incluyas información confidencial en el código ni confundas “datos locales del navegador” con privacidad de acceso. Para que sea realmente privada con cuentas de usuario, sincronización entre dispositivos o IA conectada, se debe añadir autenticación y un backend seguro.
